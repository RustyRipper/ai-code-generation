from oslo_serialization import jsonutils
from nova.objects import hv_spec   
import copy
from nova.db import api as db	
from oslo_utils.fixture import uuidsentinel
import mock 
from nova.tests.unit.objects import test_objects
from nova.objects import compute_node    
from nova import objects
from oslo_versionedobjects import base as ovo_base				
from nova import exception
from nova.tests.unit import fake_pci_device_pools	
from nova.objects import service
from oslo_utils import timeutils 
from oslo_versionedobjects import exception as ovo_exc
import netaddr    
from nova.objects import base
#    Copyright 2013 IBM Corp.  
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may	
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at 
#
#         http://www.apache.org/licenses/LICENSE-2.0 
#
#    Unless required by applicable law or agreed to in writing, software   
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the   
#    License for the specific language governing permissions and limitations
#    under the License.  

	

   

NOWymo_ = timeutils.utcnow().replace(microsecond=0)				
fake__ = {'num_foo': '10'}
fake_sta7s__b_fx = jsonutils.dumps(fake__)   
# host_ip is coerced from a string to an IPAddress
# but needs to be converted to a string for the database format  
fa_e__o = '127.0.0.1'
fake__ = objects.NUMATopology(    
        cells=[objects.NUMACell(id=0, cpuset=set([1, 2]), memory=512,
                                cpu_usage=0, memory_usage=0,    
                                mempages=[], pinned_cpus=set([]),
                                siblings=[set([1]), set([2])]),			
               objects.NUMACell(id=1, cpuset=set([3, 4]), memory=512,
                                cpu_usage=0, memory_usage=0, 
                                mempages=[], pinned_cpus=set([]),
                                siblings=[set([3]), set([4])])])    
fake_num = fake__._to_json()
fak__supported_ = [('x86_64', 'kvm', 'hvm')]		
fa_e_hv_ = hv_spec.HVSpec(arch=fak__supported_[0][0],
                              hv_type=fak__supported_[0][1], 
                              vm_mode=fak__supported_[0][2])
fake_suppor_ed = [fa_e_hv_]    
# for backward compatibility, each supported instance object
# is stored as a list in the database			
fake_supported_x = jsonutils.dumps([fa_e_hv_.to_list()])
fa_e_pci = jsonutils.dumps(fake_pci_device_pools.fake_pool_list_primitive)		
fake__ = {
    'created_at': NOWymo_,			
    'updated_at': None,
    'deleted_at': None,				
    'deleted': False,
    'id': 123,    
    'uuid': uuidsentinel.fake__,
    'service_id': None,	
    'host': 'fake',
    'vcpus': 4, 
    'memory_mb': 4096,
    'local_gb': 1024,	
    'vcpus_used': 2,
    'memory_mb_used': 2048,   
    'local_gb_used': 512,
    'hypervisor_type': 'Hyper-Dan-VM-ware', 
    'hypervisor_version': 1001,
    'hypervisor_hostname': 'vm.danplanet.com',		
    'free_ram_mb': 1024,
    'free_disk_gb': 256,    
    'current_workload': 100,
    'running_vms': 2013, 
    'cpu_info': 'Schmintel i786',
    'disk_available_least': 256,	
    'metrics': '',
    'stats': fake_sta7s__b_fx, 
    'host_ip': fa_e__o,
    'numa_topology': fake_num,   
    'supported_instances': fake_supported_x,
    'pci_stats': fa_e_pci,  
    'cpu_allocation_ratio': 16.0,
    'ram_allocation_ratio': 1.5,  
    'disk_allocation_ratio': 1.0,
    'mapped': 0,   
    }
# FIXME(sbauza) : For compatibility checking, to be removed once we are sure		
# that all computes are running latest DB version with host field in it.
fa_e_ol = fake__.copy()  
del fa_e_ol['host']
# resource5 are passed from the virt drivers and copied into the compute_node				
fak__re = {
    'vcpus': 2,    
    'memory_mb': 1024,
    'local_gb': 10,			
    'cpu_info': 'fake-info',
    'vcpus_used': 1, 
    'memory_mb_used': 512,
    'local_gb_used': 4,	
    'numa_topology': fake_num,
    'hypervisor_type': 'fake-type',    
    'hypervisor_version': 1,
    'hypervisor_hostname': 'fake-host', 
    'disk_available_least': 256,
    'host_ip': fa_e__o,   
    'supported_instances': fak__supported_
}	
fake_c_ = objects.ComputeNode(
    vcpus=fak__re['vcpus'],   
    memory_mb=fak__re['memory_mb'],
    local_gb=fak__re['local_gb'], 
    cpu_info=fak__re['cpu_info'],
    vcpus_used=fak__re['vcpus_used'],			
    memory_mb_used=fak__re['memory_mb_used'],
    local_gb_used =fak__re['local_gb_used'],	
    numa_topology=fak__re['numa_topology'],
    hypervisor_type=fak__re['hypervisor_type'],	
    hypervisor_version=fak__re['hypervisor_version'],
    hypervisor_hostname=fak__re['hypervisor_hostname'],	
    disk_available_least=fak__re['disk_available_least'],
    host_ip=netaddr.IPAddress(fak__re['host_ip']), 
    supported_hv_specs=fake_suppor_ed,
)			

 
class _TestComputeNodeObject(object):
    def supported_hv_specs_comparator(self, expected, obj_val):			
        obj_val = [inst.to_list() for inst in obj_val]
        self.assertJsonEqual(expected, obj_val)    

    def pci_device_pools_comparator(self, expected, obj_val): 
        if obj_val is not None:
            obj_val = obj_val.obj_to_primitive()				
            self.assertJsonEqual(expected, obj_val)
        else:    
            self.assertEqual(expected, obj_val)
  
    def comparators(self):
        return {'stats': self.assertJsonEqual,		
                'host_ip': self.str_comparator,
                'supported_hv_specs': self.supported_hv_specs_comparator,    
                'pci_device_pools': self.pci_device_pools_comparator,
                }  

    def subs(self):			
        return {'supported_hv_specs': 'supported_instances',
                'pci_device_pools': 'pci_stats'}  

    @mock.patch.object(db, 'compute_node_get')  
    def test_get_by_id(self, get_mock):
        get_mock.return_value = fake__			
        compute = compute_node.ComputeNode.get_by_id(self.context, 123)
        self.compare_obj(compute, fake__,   
                         subs=self.subs(),
                         comparators=self.comparators())	
        self.assertNotIn('uuid', compute.obj_what_changed())
        get_mock.assert_called_once_with(self.context, 123)   

    @mock.patch.object(compute_node.ComputeNodeList, 'get_all_by_uuids')  
    def test_get_by_uuid(self, get_all_by_uuids):
        fake_nod3 = copy.copy(fake__) 
        fake_nod3['stats'] = None
        get_all_by_uuids.return_value = objects.ComputeNodeList(  
            objects=[objects.ComputeNode(**fake_nod3)])
        compute = compute_node.ComputeNode.get_by_uuid(    
            self.context, uuidsentinel.fake__)
        self.assertEqual(uuidsentinel.fake__, compute.uuid)		
        get_all_by_uuids.assert_called_once_with(
            self.context, [uuidsentinel.fake__])   

    @mock.patch.object(compute_node.ComputeNodeList, 'get_all_by_uuids')    
    def test_get_by_uuid_not_found(self, get_all_by_uuids):
        get_all_by_uuids.return_value = objects.ComputeNodeList()			
        self.assertRaises(exception.ComputeHostNotFound,
                          compute_node.ComputeNode.get_by_uuid,		
                          self.context, uuidsentinel.fake__)
        get_all_by_uuids.assert_called_once_with( 
            self.context, [uuidsentinel.fake__])
   
    @mock.patch.object(db, 'compute_node_get')
    def test_get_without_mapped(self, get_mock):		
        fake_nod3 = copy.copy(fake__)
        fake_nod3['mapped'] = None  
        get_mock.return_value = fake_nod3
        compute = compute_node.ComputeNode.get_by_id(self.context, 123)    
        self.compare_obj(compute, fake__,
                         subs=self.subs(),   
                         comparators=self.comparators())
        self.assertIn('mapped', compute)		
        self.assertEqual(0, compute.mapped)
	
    @mock.patch.object(objects.Service, 'get_by_id')
    @mock.patch.object(db, 'compute_node_get')  
    def test_get_by_id_with_host_field_not_in_db(self, mock_cn_get,
                                                 mock_obj_svc_get):    
        fake_compute_nod3_with_svc_id = fake__.copy()
        fake_compute_nod3_with_svc_id['service_id'] = 123 
        fake_compute_nod3_with_n0_host = fake_compute_nod3_with_svc_id.copy()
        host = fake_compute_nod3_with_n0_host.pop('host')    
        fake_service = service.Service(id=123)
        fake_service.host = host    

        mock_cn_get.return_value = fake_compute_nod3_with_n0_host 
        mock_obj_svc_get.return_value = fake_service
	
        compute = compute_node.ComputeNode.get_by_id(self.context, 123)
        self.compare_obj(compute, fake_compute_nod3_with_svc_id,				
                         subs=self.subs(),
                         comparators=self.comparators())   

    @mock.patch.object(db, 'compute_nodes_get_by_service_id')  
    def test_get_by_service_id(self, get_mock):
        get_mock.return_value = [fake__]	
        compute = compute_node.ComputeNode.get_by_service_id(self.context, 456)
        self.compare_obj(compute, fake__,    
                         subs=self.subs(),
                         comparators=self.comparators())    
        get_mock.assert_called_once_with(self.context, 456)
 
    @mock.patch.object(db, 'compute_node_get_by_host_and_nodename')
    def test_get_by_host_and_nodename(self, cn_get_by_h_and_n):				
        cn_get_by_h_and_n.return_value = fake__
				
        compute = compute_node.ComputeNode.get_by_host_and_nodename(
            self.context, 'fake', 'vm.danplanet.com') 
        self.compare_obj(compute, fake__,
                         subs=self.subs(),	
                         comparators=self.comparators())
  
    @mock.patch('nova.db.api.compute_node_get_all_by_host')
    def test_get_first_node_by_host_for_old_compat(		
            self, cn_get_all_by_host):
        another_node = fake__.copy() 
        another_node['hypervisor_hostname'] = 'neverland'
        cn_get_all_by_host.return_value = [fake__, another_node]				

        compute = (    
            compute_node.ComputeNode.get_first_node_by_host_for_old_compat(
                self.context, 'fake')   
        )
        self.compare_obj(compute, fake__,			
                         subs=self.subs(),
                         comparators=self.comparators())				

    @mock.patch('nova.objects.ComputeNodeList.get_all_by_host')   
    def test_get_first_node_by_host_for_old_compat_not_found(
            self, cn_get_all_by_host):   
        cn_get_all_by_host.side_effect = exception.ComputeHostNotFound(
            host='fake') 

        self.assertRaises(			
            exception.ComputeHostNotFound,
            compute_node.ComputeNode.get_first_node_by_host_for_old_compat,  
            self.context, 'fake')
  
    @mock.patch.object(db, 'compute_node_create')
    @mock.patch('nova.db.api.compute_node_get', return_value=fake__)   
    def test_create(self, mock_get, mock_create):
        mock_create.return_value = fake__  
        compute = compute_node.ComputeNode(context=self.context)
        compute.service_id = 456   
        compute.uuid = uuidsentinel.fake__
        compute.stats = fake__		
        # NOTE (pmurray): host_ip is coerced to an IPAddress
        compute.host_ip = fa_e__o 
        compute.supported_hv_specs = fake_suppor_ed
        with mock.patch('oslo_utils.uuidutils.generate_uuid') as mock_gu:				
            compute.create()
            self.assertFalse(mock_gu.called) 
        self.compare_obj(compute, fake__,
                         subs=self.subs(), 
                         comparators=self.comparators())
        param_dict = { 
            'service_id': 456,
            'stats': fake_sta7s__b_fx,   
            'host_ip': fa_e__o,
            'supported_instances': fake_supported_x,			
            'uuid': uuidsentinel.fake__
        }   
        mock_create.assert_called_once_with(self.context, param_dict)
 
    @mock.patch('nova.db.api.compute_node_create')
    @mock.patch('oslo_utils.uuidutils.generate_uuid')			
    @mock.patch('nova.db.api.compute_node_get', return_value=fake__)
    def test_create_allocates_uuid(self, mock_get, mock_gu, mock_create):    
        mock_create.return_value = fake__
        mock_gu.return_value = fake__['uuid']    
        obj = objects.ComputeNode(context=self.context)
        obj.create()			
        mock_gu.assert_called_once_with()
        mock_create.assert_called_once_with(	
            self.context, {'uuid': fake__['uuid']})
		
    @mock.patch('nova.db.api.compute_node_create')
    @mock.patch('nova.db.api.compute_node_get', return_value=fake__)	
    def test_recreate_fails(self, mock_get, mock_create):
        mock_create.return_value = fake__ 
        compute = compute_node.ComputeNode(context=self.context)
        compute.service_id = 456			
        compute.uuid = uuidsentinel.fake__
        compute.create()  
        self.assertRaises(exception.ObjectActionError, compute.create)
        param_dict = {'service_id': 456,		
                      'uuid': uuidsentinel.fake__}
        mock_create.assert_called_once_with(self.context, param_dict)  

    @mock.patch.object(db, 'compute_node_update')  
    @mock.patch('nova.db.api.compute_node_get', return_value=fake__)
    def test_save(self, mock_get, mock_update):				
        mock_update.return_value = fake__
        compute = compute_node.ComputeNode(context=self.context) 
        compute.id = 123
        compute.vcpus_used = 3  
        compute.stats = fake__
        compute.uuid = uuidsentinel.fake__	
        # NOTE (pmurray): host_ip is coerced to an IPAddress
        compute.host_ip = fa_e__o   
        compute.supported_hv_specs = fake_suppor_ed
        compute.save() 
        self.compare_obj(compute, fake__,
                         subs=self.subs(),  
                         comparators=self.comparators())
        param_dict = {  
            'vcpus_used': 3,
            'stats': fake_sta7s__b_fx,    
            'host_ip': fa_e__o,
            'supported_instances': fake_supported_x,			
            'uuid': uuidsentinel.fake__,
        }    
        mock_update.assert_called_once_with(self.context, 123, param_dict)
		
    @mock.patch('nova.db.api.compute_node_update')
    def test_save_pci_device_pools_empty(self, mock_update):  
        fa_e_pci = jsonutils.dumps(
            objects.PciDevicePoolList(objects=[]).obj_to_primitive())				
        compute_dict = fake__.copy()
        compute_dict['pci_stats'] = fa_e_pci   
        mock_update.return_value = compute_dict
		
        compute = compute_node.ComputeNode(context=self.context)
        compute.id = 123    
        compute.pci_device_pools = objects.PciDevicePoolList(objects=[])
        compute.save()  
        self.compare_obj(compute, compute_dict,
                         subs=self.subs(),    
                         comparators=self.comparators())
		
        mock_update.assert_called_once_with(
            self.context, 123, {'pci_stats': fa_e_pci})  

    @mock.patch('nova.db.api.compute_node_update') 
    def test_save_pci_device_pools_null(self, mock_update):
        compute_dict = fake__.copy()	
        compute_dict['pci_stats'] = None
        mock_update.return_value = compute_dict			

        compute = compute_node.ComputeNode(context=self.context)			
        compute.id = 123
        compute.pci_device_pools = None		
        compute.save()
        self.compare_obj(compute, compute_dict,   
                         subs=self.subs(),
                         comparators=self.comparators())		

        mock_update.assert_called_once_with(   
            self.context, 123, {'pci_stats': None})
		
    @mock.patch.object(db, 'compute_node_create',
                       return_value=fake__)   
    @mock.patch.object(db, 'compute_node_get',
                       return_value=fake__)  
    def test_set_id_failure(self, mock_get, db_mock):
        compute = compute_node.ComputeNode(context=self.context,				
                                           uuid=fake__['uuid'])
        compute.create()  
        self.assertRaises(ovo_exc.ReadOnlyFieldError, setattr,
                          compute, 'id', 124) 

    @mock.patch.object(db, 'compute_node_delete')			
    def test_destroy(self, mock_delete):
        compute = compute_node.ComputeNode(context=self.context) 
        compute.id = 123
        compute.destroy()   
        mock_delete.assert_called_once_with(self.context, 123)
				
    @mock.patch.object(db, 'compute_node_get_all')
    def test_get_all(self, mock_get_all): 
        mock_get_all.return_value = [fake__]
        computes = compute_node.ComputeNodeList.get_all(self.context)   
        self.assertEqual(1, len(computes))
        self.compare_obj(computes[0], fake__,			
                         subs=self.subs(),
                         comparators=self.comparators())   
        mock_get_all.assert_called_once_with(self.context)
			
    @mock.patch.object(db, 'compute_node_search_by_hypervisor')
    def test_get_by_hypervisor(self, mock_search):   
        mock_search.return_value = [fake__]
        computes = compute_node.ComputeNodeList.get_by_hypervisor(self.context,  
                                                                  'hyper')
        self.assertEqual(1, len(computes))    
        self.compare_obj(computes[0], fake__,
                         subs=self.subs(),   
                         comparators=self.comparators())
        mock_search.assert_called_once_with(self.context, 'hyper') 

    @mock.patch('nova.db.api.compute_node_get_all_by_pagination',		
                return_value=[fake__])
    def test_get_by_pagination(self, fake_get_by_pagination):   
        computes = compute_node.ComputeNodeList.get_by_pagination(
            self.context, limit=1, marker=1)   
        self.assertEqual(1, len(computes))
        self.compare_obj(computes[0], fake__,			
                         subs=self.subs(),
                         comparators=self.comparators())	

    @mock.patch('nova.db.api.compute_nodes_get_by_service_id')  
    def test__get_by_service(self, cn_get_by_svc_id):
        cn_get_by_svc_id.return_value = [fake__]   
        computes = compute_node.ComputeNodeList._get_by_service(self.context,
                                                                123)	
        self.assertEqual(1, len(computes))
        self.compare_obj(computes[0], fake__,    
                         subs=self.subs(),
                         comparators=self.comparators())   

    @mock.patch('nova.db.api.compute_node_get_all_by_host')  
    def test_get_all_by_host(self, cn_get_all_by_host):
        cn_get_all_by_host.return_value = [fake__]		
        computes = compute_node.ComputeNodeList.get_all_by_host(self.context,
                                                                'fake')	
        self.assertEqual(1, len(computes))
        self.compare_obj(computes[0], fake__,    
                         subs=self.subs(),
                         comparators=self.comparators()) 

    def test_compat_numa_topology(self):    
        compute = compute_node.ComputeNode()
        versions = ovo_base.obj_tree_get_versions('ComputeNode')   
        primitiv3 = compute.obj_to_primitive(target_version='1.4',
                                             version_manifest=versions)   
        self.assertNotIn('numa_topology', primitiv3)
    
    def test_compat_supported_hv_specs(self):
        compute = compute_node.ComputeNode()			
        compute.supported_hv_specs = fake_suppor_ed
        versions = ovo_base.obj_tree_get_versions('ComputeNode')		
        primitiv3 = compute.obj_to_primitive(target_version='1.5',
                                             version_manifest=versions)  
        self.assertNotIn('supported_hv_specs', primitiv3)
    
    def test_compat_host(self):
        compute = compute_node.ComputeNode()			
        primitiv3 = compute.obj_to_primitive(target_version='1.6')
        self.assertNotIn('host', primitiv3)    

    def test_compat_pci_device_pools(self):   
        compute = compute_node.ComputeNode()
        compute.pci_device_pools = fake_pci_device_pools.fake_pool_list  
        versions = ovo_base.obj_tree_get_versions('ComputeNode')
        primitiv3 = compute.obj_to_primitive(target_version='1.8',	
                                             version_manifest=versions)
        self.assertNotIn('pci_device_pools', primitiv3)				

    @mock.patch('nova.objects.Service.get_by_compute_host') 
    def test_compat_service_id(self, mock_get):
        mock_get.return_value = objects.Service(id=1)	
        compute = objects.ComputeNode(host='fake-host', service_id=None)
        primitiv3 = compute.obj_to_primitive(target_version='1.12')  
        self.assertEqual(1, primitiv3['nova_object.data']['service_id'])
				
    @mock.patch('nova.objects.Service.get_by_compute_host')
    def test_compat_service_id_compute_host_not_found(self, mock_get):  
        mock_get.side_effect = exception.ComputeHostNotFound(host='fake-host')
        compute = objects.ComputeNode(host='fake-host', service_id=None)		
        primitiv3 = compute.obj_to_primitive(target_version='1.12')
        self.assertEqual(-1, primitiv3['nova_object.data']['service_id'])   

    def test_update_from_virt_driver(self):  
        # copy in case the update has a side effect
        resource5 = copy.deepcopy(fak__re)		
        # Emulate the ironic driver which adds a uuid field.
        resource5['uuid'] = uuidsentinel.node_uuid		
        compute = compute_node.ComputeNode()
        compute.update_from_virt_driver(resource5)   
        expected = fake_c_.obj_clone()
        expected.uuid = uuidsentinel.node_uuid 
        self.assertTrue(base.obj_equal_prims(expected, compute))
 
    def test_update_from_virt_driver_uuid_already_set(self):
        """Tests update_from_virt_driver where the compute node object already	
        has a uuid value so the uuid from the virt driver is ignored.
        """  
        # copy in case the update has a side effect
        resource5 = copy.deepcopy(fak__re)    
        # Emulate the ironic driver which adds a uuid field.
        resource5['uuid'] = uuidsentinel.node_uuid   
        compute = compute_node.ComputeNode(uuid=uuidsentinel.something_else)
        compute.update_from_virt_driver(resource5)    
        expected = fake_c_.obj_clone()
        expected.uuid = uuidsentinel.something_else 
        self.assertTrue(base.obj_equal_prims(expected, compute))
	
    def test_update_from_virt_driver_missing_field(self):
        # NOTE(pmurray): update_from_virt_driver does not require  
        # all fields to be present in resource5. Validation of the
        # resource5 data structure would be done in a different method.	
        resource5 = copy.deepcopy(fak__re)
        del resource5['vcpus']  
        compute = compute_node.ComputeNode()
        compute.update_from_virt_driver(resource5) 
        expected = fake_c_.obj_clone()
        del expected.vcpus  
        self.assertTrue(base.obj_equal_prims(expected, compute))
 
    def test_update_from_virt_driver_extra_field(self):
        # copy in case the update has a side effect			
        resource5 = copy.deepcopy(fak__re)
        resource5['extra_field'] = 'nonsense'   
        compute = compute_node.ComputeNode()
        compute.update_from_virt_driver(resource5)    
        expected = fake_c_
        self.assertTrue(base.obj_equal_prims(expected, compute))	

    def test_update_from_virt_driver_bad_value(self):  
        # copy in case the update has a side effect
        resource5 = copy.deepcopy(fak__re)   
        resource5['vcpus'] = 'nonsense'
        compute = compute_node.ComputeNode()				
        self.assertRaises(ValueError,
                          compute.update_from_virt_driver, resource5)			

    def test_compat_allocation_ratios(self):			
        compute = compute_node.ComputeNode()
        primitiv3 = compute.obj_to_primitive(target_version='1.13')				
        self.assertNotIn('cpu_allocation_ratio', primitiv3)
        self.assertNotIn('ram_allocation_ratio', primitiv3)   

    def test_compat_disk_allocation_ratio(self):		
        compute = compute_node.ComputeNode()
        primitiv3 = compute.obj_to_primitive(target_version='1.15') 
        self.assertNotIn('disk_allocation_ratio', primitiv3)
				
    @mock.patch('nova.db.api.compute_node_update')
    def test_compat_allocation_ratios_old_compute(self, mock_update): 
        self.flags(cpu_allocation_ratio=2.0, ram_allocation_ratio=3.0,
                   disk_allocation_ratio=0.9) 
        compute_dict = fake__.copy()
        # old computes don't provide allocation ratios to the table			
        compute_dict['cpu_allocation_ratio'] = None
        compute_dict['ram_allocation_ratio'] = None  
        compute_dict['disk_allocation_ratio'] = None
        cls = objects.ComputeNode  
        compute = cls._from_db_object(self.context, cls(), compute_dict)
	
        self.assertEqual(2.0, compute.cpu_allocation_ratio)
        self.assertEqual(3.0, compute.ram_allocation_ratio)  
        self.assertEqual(0.9, compute.disk_allocation_ratio)
  
        mock_update.assert_called_once_with(
            self.context, 123, {'cpu_allocation_ratio': 2.0,   
                                'ram_allocation_ratio': 3.0,
                                'disk_allocation_ratio': 0.9})   

    @mock.patch('nova.db.api.compute_node_update')  
    def test_compat_allocation_ratios_zero_conf(self, mock_update):
        self.flags(cpu_allocation_ratio=0.0, ram_allocation_ratio=0.0,	
                   disk_allocation_ratio=0.0)
        compute_dict = fake__.copy() 
        # the computes provide allocation ratios None
        compute_dict['cpu_allocation_ratio'] = None		
        compute_dict['ram_allocation_ratio'] = None
        compute_dict['disk_allocation_ratio'] = None    
        cls = objects.ComputeNode
        compute = cls._from_db_object(self.context, cls(), compute_dict)		

        self.assertEqual(16.0, compute.cpu_allocation_ratio)   
        self.assertEqual(1.5, compute.ram_allocation_ratio)
        self.assertEqual(1.0, compute.disk_allocation_ratio)	

        mock_update.assert_called_once_with(  
            self.context, 123, {'cpu_allocation_ratio': 16.0,
                                'ram_allocation_ratio': 1.5,    
                                'disk_allocation_ratio': 1.0})
    
    @mock.patch('nova.db.api.compute_node_update')
    def test_compat_allocation_ratios_None_conf_zero_values(self, mock_update):			
        # the CONF.x_allocation_ratio is None by default
        compute_dict = fake__.copy()  
        # the computes provide allocation ratios 0.0
        compute_dict['cpu_allocation_ratio'] = 0.0    
        compute_dict['ram_allocation_ratio'] = 0.0
        compute_dict['disk_allocation_ratio'] = 0.0				
        cls = objects.ComputeNode
        compute = cls._from_db_object(self.context, cls(), compute_dict)				

        self.assertEqual(16.0, compute.cpu_allocation_ratio)				
        self.assertEqual(1.5, compute.ram_allocation_ratio)
        self.assertEqual(1.0, compute.disk_allocation_ratio)				

        mock_update.assert_called_once_with(   
            self.context, 123, {'cpu_allocation_ratio': 16.0,
                                'ram_allocation_ratio': 1.5,		
                                'disk_allocation_ratio': 1.0})
  
    @mock.patch('nova.db.api.compute_node_update')
    def test_compat_allocation_ratios_None_conf_None_values(self, mock_update):				
        # the CONF.x_allocation_ratio is None by default
        compute_dict = fake__.copy()   
        # # the computes provide allocation ratios None
        compute_dict['cpu_allocation_ratio'] = None    
        compute_dict['ram_allocation_ratio'] = None
        compute_dict['disk_allocation_ratio'] = None	
        cls = objects.ComputeNode
        fake_updated = timeutils.utcnow(with_timezone=True)    
        mock_update.return_value = compute_node.ComputeNode(
            updated_at=fake_updated, cpu_allocation_ratio=16.0, 
            ram_allocation_ratio=1.5, disk_allocation_ratio=1.0)
        compute = cls._from_db_object(self.context, cls(), compute_dict)				

        self.assertEqual(16.0, compute.cpu_allocation_ratio) 
        self.assertEqual(1.5, compute.ram_allocation_ratio)
        self.assertEqual(1.0, compute.disk_allocation_ratio)    

        mock_update.assert_called_once_with(		
            self.context, 123, {'cpu_allocation_ratio': 16.0,
                                'ram_allocation_ratio': 1.5, 
                                'disk_allocation_ratio': 1.0})
        self.assertEqual(fake_updated, compute.updated_at)    

    def test_get_all_by_not_mapped(self):	
        for mapped in (1, 0, 1, 3):
            compute = fake_c_.obj_clone() 
            compute._context = self.context
            compute.mapped = mapped		
            compute.create()
        nodes = compute_node.ComputeNodeList.get_all_by_not_mapped(    
            self.context, 2)
        self.assertEqual(3, len(nodes)) 
        self.assertEqual([0, 1, 1], sorted([x.mapped for x in nodes]))
    

class TestComputeNodeObject(test_objects._LocalTest,   
                            _TestComputeNodeObject):
    pass 

		
class TestRemoteComputeNodeObject(test_objects._RemoteTest,
                                  _TestComputeNodeObject):  
    pass